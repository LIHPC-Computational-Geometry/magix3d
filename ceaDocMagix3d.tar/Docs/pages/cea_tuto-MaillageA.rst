Maillage d'une amorce
#####################