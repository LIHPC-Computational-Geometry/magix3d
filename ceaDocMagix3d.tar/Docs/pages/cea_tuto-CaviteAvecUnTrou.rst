Maillage d'une cavité avec un trou
##################################

Préambule
*********

L'objectif est de réaliser un trou dans une cavité 2D
axisymétrique (sans cône de protection). Nous proposons ici une
méthode pour y arriver. Méthode dont il est possible de
s'inspirer pour réaliser d'autres maillages. D'autres méthodes
permettent d'arriver au même maillage, nous souhaitons
présenter ici une méthode facilement réutilisable dans une autre configuration.

Nous utilisons un modèle 2D sans découpage des zones dans
l'épaisseur de la cavité pour éviter de retrouver des volumes
en 3D pour chacune de ces zones alors qu'il n'y a qu'un seul
matériau. Les groupes comme matériaux pour le jeu de données

|caviteVolumes|

Pré-requis
**********

Il est nécessaire d'avoir compris le fonctionnement des :ref:`précédents tutoriels<index-tutoriels>` et de comprendre l'intérêt de la décomposition par blocs en :ref:`o-grid<o-grid>`.

Nous avons un modèle 2D construit à l'aide de Magix. Ce modèle est constitué d'un ensemble de zones structurées. 
Le fichier MDL : :download:`mdl <../resources/cea_cavite.mdl>`

Importation du modèle 2D
************************

La commande est accessible dans le menu *Session/Importer...*
Sélectionner ensuite le fichier *cavite.mdl* (vous pouvez entrer le nom avec le chemin complet dans le champ *File name*).

Valider ensuite avec l'option par défaut *Importer la topologie*.

Si vous n'affichez que les courbes, vous obtenez ceci :

|caviteCourbes2D|

Le panneau *Commandes python* fait alors apparaître la commande suivantes :

.. code-block:: python
  
  ctx.getTopoManager().importMDL("/xxx/cavite.mdl",False,False)

Découpage de la topologie pour placer l'o-grid
**********************************************

Ouvrir le panneau *Découpage d'une face selon une arête* qui est accesion de la forme des arêtes à l’intérieursible depuis le panneau *Opérations*
en sélectionnant les boutons suivants :

.. taboperation:: 
      :famille: topologie
      :sousfamille: faces
      :operation: découpageface

Vous allez ensuite sélectionner les entités pour remplir les champs comme suit :

.. taboperationparams::
      :valeurs: Toutes les faces, Coché
                Arête, Ar0003

Exécuter la commande avec le bouton *Appliquer*.

Le panneau *Commandes python* fait alors apparaître la commande équivalente :

.. code-block:: python

  ctx.getTopoManager().splitAllFaces ("Ar0003", .5, .5)

Création de la topologie 3D (et de la géométrie) par révolution
***************************************************************

Il vous faut ouvrir le panneau *Création de blocs par révolution* qui est accessible depuis le panneau *Opérations* en sélectionnant les boutons suivants :

.. taboperation:: 
      :famille: topologie
      :sousfamille: blocs
      :operation: blocparrévolution

Vous allez ensuite sélectionner l'entité et modifier la portion pour remplir les champs comme suit :

.. taboperationparams::
      :valeurs: Arête, Ar0023
                Portion, Entier

Exécuter la commande avec le bouton *Appliquer*.

Le panneau *Commandes python* fait alors apparaître la commande équivalente :

.. code-block:: python

  ctx.getTopoManager().makeBlocksByRevol (["Ar0023"], Mgx3D.Portion.ENTIER)

La topologie des arêtes a maintenant cet aspect :

 |caviteAretes3D|

Création du cylindre pour percer la cavité
******************************************

Pour percer la cavité, nous allons créer un volume cylindrique (sans topologie), il faut pour cela ouvrir le panneau *Création de cylindre* 
qui est accessible depuis le panneau *Opérations* en sélectionnant les boutons suivants :

.. taboperation:: 
      :famille: géométrie
      :sousfamille: volumes
      :operation: cylindre

Modifier les champs suivants et *Appliquer* :

.. taboperationparams::
      :valeurs: Groupe, CUT
                Centre de la base x, 5
                Centre de la base y, 3
                Vecteur directeur dx, 0
                Vecteur directeur dz, 2
                Création d'une topologie associée, Décoché

La commande Python :

.. code-block:: python

  ctx.getGeomManager().newCylinder (Mgx3D.Point(5, 0, 3), 1, Mgx3D.Vector(0, 0, 2), 3.600000e+02, "CUT")

Perçage de la cavité
********************

Il vous faut ouvrir le panneau *Opérations booléennes sur des volumes* qui est accessible depuis le panneau *Opérations* en sélectionnant les boutons suivants :

.. taboperation:: 
      :famille: géométrie
      :sousfamille: volumes
      :operation: operationsbooléennes

Ensuite, sélectionner comme type d'opération la *Section*

Sélectionner comme volume à couper celui de la cavité (Vol0002) à l'aide du champ de sélection
Sélectionner comme surface pour couper celle qui est circulaire et dans le volume de CUT (Surf0018).

La commande Python :

.. code-block:: python

  ctx.getGeomManager().section(["Vol0002"], "Surf0018")

La géométrie comporte alors 4 volumes:

|caviteTrouee|

Suppression de l'outil pour trouer
**********************************

Il faut pour cela ouvrir le panneau *Destruction d'entités géométriques* qui est accessible depuis le panneau *Opérations* en sélectionnant les boutons suivants :

.. taboperation:: 
      :famille: géométrie
      :sousfamille: volumes
      :operation: destruction

Sélectionner comme volume à détruire celui de *CUT (Vol0004)* à l'aide du champ de sélection.

La commande Python :

.. code-block:: python

  ctx.getGeomManager().destroy(["Vol0004"], True)

Création du groupe pour le trou
*******************************

Cette opération permet de mettre dans un groupe spécifique le volume issu de la coupe, et donc que le maillage de ce volume soit dans ce groupe.

Il faut pour cela ouvrir le panneau *Ajout/suppression/affectation d'entités géométriques à un groupe* qui est accessible depuis le panneau *Opérations* en sélectionnant les boutons suivants:

.. taboperation:: 
      :famille: géométrie
      :sousfamille: volumes
      :operation: geomtogroupe

Modifier les champs suivants et *Appliquer* :

.. taboperationparams::
      :valeurs: Groupe, TROU
                Opération, Affecter
                Entités géométriques, Vol0005

La commande Python :

.. code-block:: python

  ctx.getGeomManager().setGroup (["Vol0005"], 3, "TROU")

Modification des méthodes de maillage
*************************************

La méthode de maillage par défaut des blocs issus de la révolution est optimisée pour la qualité et la rapidité de la création du maillage. Mais comme nous allons modifier (découper) certain de ces blocs, il est préférable de mettre une méthode de maillage plus général.

Pour cela ouvrir le panneau *Paramétrage du maillage des blocs* qui est accessible depuis le panneau *Opérations* en sélectionnant les boutons suivants :

.. taboperation:: 
      :famille: topologie
      :sousfamille: blocs
      :operation: maillageblocs

Vous allez ensuite sélectionner les 2 blocs pour remplir les champs comme suite, puis *Appliquer* :

.. taboperationparams::
      :valeurs: Blocs, Bl0001 Bl0003

La commande Python :

.. code-block:: python

  ctx.getTopoManager().setMeshingProperty (Mgx3D.BlockMeshingPropertyTransfinite(),["Bl0001", "Bl0003"])

Découpage de la topologie pour coller au trou
*********************************************

Nous choisissons dans ce qui suit un découpage en ogrid autours du trou. Un découpage préalable des blocs permettrait de restreindre l'impact de l\':ref:`o-grid<o-grid>`.

Pour cela ouvrir le panneau *Découpage de bloc avec o-grid* qui est accessible depuis le panneau *Opérations* en sélectionnant les boutons suivants :

.. taboperation:: 
      :famille: topologie
      :sousfamille: blocs
      :operation: découpageblocogrid

Vous allez ensuite sélectionner les entités pour remplir les champs comme suite, puis *Appliquer* :

.. taboperationparams::
      :valeurs: Blocs, Bl0001 Bl0003
                Faces, Fa0036
                Ratio, 0.3

La commande Python :

.. code-block:: python

  ctx.getTopoManager().splitBlocksWithOgrid (["Bl0001", "Bl0003"], ["Fa0036"], .3, 10)

Les extrémités du centre de l\':ref:`o-grid<o-grid>` apparaissent mais sont encore à rectifier pour se positionner à proximité du trou :

.. figure:: ../images/cea_Cavite_splitBlocks.jpeg
   :width: 350px
   
   Le découpage en o-grid pour le trou

Associations des sommets au bord du trou
****************************************

Cette étape permet également de déplacer les sommets.On procède d'abord pour les 4 sommets qui sont projetés sur la courbe supérieure du trou, puis de même avec celle inférieure.

Lorsque les champs du panneau seront remplis comme suite, exécuter la commande avec le bouton *Appliquer* :

.. taboperationparams::
      :valeurs: Méthode , E. Topologiques -> E. géométrique 
                Entité Topologiques, Som0062 Som0070 Som0063 Som0055
                D1 (géométrique), Coché
                Entité géométrique, Crb0037

Recommencer avec : 

.. taboperationparams::
      :valeurs: Entité Topologiques,  Som0059 Som0067 Som0066 Som0058
                Entité géométrique, Crb0038

Les commandes Python :

.. code-block:: python

  ctx.getTopoManager().setGeomAssociation (["Som0062", "Som0070", "Som0063", "Som0055"], "Crb0037", True)
  ctx.getTopoManager().setGeomAssociation (["Som0059", "Som0067", "Som0066", "Som0058"], "Crb0038", True)

Création d'un repère local pour faciliter le positionnement des sommets
***********************************************************************

.. taboperation:: 
      :famille: repère
      :sousfamille: repère
      :operation: repère

Vous allez ensuite remplir les champs comme suit, puis *Appliquer* :

.. taboperationparams::
      :valeurs: Groupe, TROU
                Méthode,  Suivant un centre 
                x, 5
                y, 3

La commande Python :

.. code-block:: python

  ctx.getSysCoordManager().newSysCoord (Mgx3D.Point(5, 0, 3), "TROU")

Modification de la position du bloc sous le trou, dans le vide, en utilisant un repère local
********************************************************************************************

Les sommets du bord du trou ont été projetés où il se doit, mais si l'on ne déplace pas les sommets de l'ogrid sous le trou 
le maillage sera très déformé dans le vide, voir avec des mailles croisées. Pour cela nous allons utiliser le repère local 
précédemment créé et positionner les points à l'aide du panneau *Modification des coordonnées de sommets topologiques* qui 
est accessible depuis le panneau *Opérations* en sélectionnant les boutons suivants :

.. taboperation:: 
      :famille: topologie
      :sousfamille: sommets
      :operation: coordonnéessommets

Dans un premier temps nous allons mettre dans un même plan une série de sommmets autours et au bord du trou. NB, il faut remplir le (dernier) champ repère en premier.

Vous allez ensuite remplir les champs dans l'ordre comme suit, puis *Appliquer* :

.. taboperationparams::
      :valeurs: Repère, Rep0000
                Sommets, Som0063 Som0066 Som0074 Som0075 
                Type de coordonnées, Cylindriques
                Phi, -45
                Modifier, Coché (pour Phi)

Il faut ensuite répéter l'opération avec les différents sommets pour les 4 plans. Ensuite il faut remonter les sommets proche du trou et donc modifier Rhô et Z (et plus Phi). 

.. note::
  Astuce: ne pas hésiter à sélectionner un sommet avec le champ *Vertex* pour préremplir les champs et avoir une valeur de départ. 

Les commandes Python :

.. code-block:: python

  ctx.getTopoManager().setVertexCylindricalLocation (["Som0063", "Som0066", "Som0074", "Som0075"], False, 0, True, -45, False, 0, "Rep0000")
  ctx.getTopoManager().setVertexCylindricalLocation (["Som0055", "Som0058", "Som0071", "Som0072"], False, 0, True, 45, False, 0, "Rep0000")
  ctx.getTopoManager().setVertexCylindricalLocation (["Som0062", "Som0059", "Som0073"], False, 0, True, 135, False, 0, "Rep0000")
  ctx.getTopoManager().setVertexCylindricalLocation (["Som0070", "Som0067", "Som0076"], False, 0, True, -135, False, 0, "Rep0000")

  ctx.getTopoManager().setVertexCylindricalLocation (["Som0074", "Som0071"], True, 1.2, False, 0, True, .72, "Rep0000")

  ctx.getTopoManager().setVertexCylindricalLocation (["Som0076", "Som0073", "Som0072", "Som0075"], True, 1, False, 0, True, .5, "Rep0000")

Les extrémités du centre de l\':ref:`o-grid<o-grid>` sont maintenant placées correctement :

|cavitePosBlocsTrou|

Extraction du bloc du trou
**************************

Nous séparons la topologie du trou du reste de la topologie pour se permettre la création de blocs nouveaux entre les deux.

Pour cela ouvrir le panneau *Extrait des blocs* qui est accessible depuis le panneau *Opérations* en sélectionnant les boutons suivants :

.. taboperation:: 
      :famille: topologie
      :sousfamille: blocs
      :operation: extraitblocs

Lorsque les champs du panneau seront remplis comme suite, exécuter la commande avec le bouton *Appliquer* :

.. taboperationparams::
      :valeurs: Groupe, TMP_TROU
                Blocs à copier, Bl0018

La commande Python :

.. code-block:: python

  ctx.getTopoManager().extract (["Bl0018"], "TMP_TROU")

Association des arêtes du bord du trou aux courbes
**************************************************

Il est recommandé de masquer la topologie du trou pour la suite. Seul le groupe Cavite est visible.

Ouvrir le panneau *Associations blocs topologiques -> volume géométrique* qui est accessible depuis le panneau *Opérations* en sélectionnant les boutons suivants :

.. taboperation:: 
      :famille: topologie
      :sousfamille: arêtes
      :operation: associations

Sélectionner la méthode de projection pour les arêtes, puis sélectionner les arêtes au bord du trou et le long des courbes supérieures et inférieures.

Lorsque les champs du panneau seront remplis comme suit, exécuter la commande avec le bouton *Appliquer* :

.. taboperationparams::
      :valeurs: Méthode,Arêtes -> Courbes 
                Arêtes, Ar0165 Ar0157 Ar0166 Ar0161 Ar0159 Ar0163 Ar0155 Ar0164

La commande Python :

.. code-block:: python

  ctx.getTopoManager().projectEdgesOnCurves (["Ar0165", "Ar0157", "Ar0166", "Ar0161", "Ar0159", "Ar0163", "Ar0155", "Ar0164"])

Découpage des arêtes de la cavité au bord du trou
*************************************************

Il s'agit avec cette étape de faire apparaitre au bord du trou le découpage en 3 qui est déjà présent dans l'épaisseur de la cavité.

Pour cela ouvrir le panneau *Découpage d'arêtes topologiques* qui est accessible depuis le panneau *Opérations* en sélectionnant les boutons suivants :

.. taboperation:: 
      :famille: topologie
      :sousfamille: arêtes
      :operation: decoupagearetes

Les commandes Python :

.. code-block:: python

  ctx.getTopoManager().splitEdge ("Ar0160", .7)
  ctx.getTopoManager().splitEdge ("Ar0156", .7)
  ctx.getTopoManager().splitEdge ("Ar0162", .7)
  ctx.getTopoManager().splitEdge ("Ar0158", .7)
  ctx.getTopoManager().splitEdge ("Ar0190", .4286)
  ctx.getTopoManager().splitEdge ("Ar0192", .4286)
  ctx.getTopoManager().splitEdge ("Ar0194", .5714)
  ctx.getTopoManager().splitEdge ("Ar0196", .5714)

Modification des discrétisations des nouvelles arêtes
*****************************************************

Le découpage a placé de nouveaux sommets au bord du trou, mais les discrétisations ne sont pas équivalentes à celles sur les autres arêtes de la cavité. 
Pour rectifier cela, ouvrir le panneau *Paramétrage de la discrétisation des arêtes* qui est accessible depuis le panneau *Opérations* en sélectionnant les boutons suivants :

.. taboperation:: 
      :famille: topologie
      :sousfamille: arêtes
      :operation: discrétisation

Sélectionner une des arêtes avec laquelle nous voulons être équivalent, utiliser le bouton *Actualiser le panneau*, ce qui remplit les paramètres de la discrétisation, sélectionner ensuite les arêtes auxquelles on souhaite appliquer cette discrétisation.

Certaines de ces arêtes ont une progression qui est en sens inverse, cela peut se voir en affichant les *Points* dans le menu *Représentations... des Arêtes*.

Utiliser ensuite le panneau *Sens de discrétisation d'arêtes topologiques* qui est accessible depuis le panneau *Opérations* en sélectionnant les boutons suivants :

.. taboperation:: 
      :famille: topologie
      :sousfamille: arêtes
      :operation: sensdiscrétisation

Les commandes Python :

.. code-block:: python

  
  emp = Mgx3D.EdgeMeshingPropertyGeometric(10,1.2)
  ctx.getTopoManager().setMeshingProperty (emp,["Ar0191", "Ar0198", "Ar0200", "Ar0193", "Ar0204", "Ar0197", "Ar0195", "Ar0202"])
  emp = Mgx3D.EdgeMeshingPropertyUniform(4)
  ctx.getTopoManager().setMeshingProperty (emp,["Ar0205", "Ar0203", "Ar0199", "Ar0201"])
  ctx.getTopoManager().reverseDirection (["Ar0197", "Ar0195", "Ar0191", "Ar0193"])

Découpage des faces au bord du trou
***********************************

Pour permettre le collage avec les blocs que nous allons construire autour du trou, il est nécessaire de découper les faces suivant le découpage des arêtes.

Il vous faut ouvrir le panneau *Prolongation de découpage de face* à partir d'un sommet situé sur une arête qui est accessible depuis le panneau *Opérations* en sélectionnant les boutons suivants :

.. taboperation:: 
      :famille: topologie
      :sousfamille: faces
      :operation: prolongation

Les commandes Python :

.. code-block:: python

  ctx.getTopoManager().extendSplitFace ("Fa0120", "Som0085")
  ctx.getTopoManager().extendSplitFace ("Fa0135", "Som0089")
  ctx.getTopoManager().extendSplitFace ("Fa0116", "Som0086")
  ctx.getTopoManager().extendSplitFace ("Fa0138", "Som0090")
  ctx.getTopoManager().extendSplitFace ("Fa0117", "Som0085")
  ctx.getTopoManager().extendSplitFace ("Fa0142", "Som0089")
  ctx.getTopoManager().extendSplitFace ("Fa0121", "Som0091")
  ctx.getTopoManager().extendSplitFace ("Fa0146", "Som0087")

Rectification de la position des sommets internes à la cavité
*************************************************************

Il s'agit là de déplacer vers l'intérieur de la cavité les 8 sommets que nous venons de créer de manière à ce qu'ils deviennent les sommets de l'ogrid au bord du trou.

Ouvrir le panneau *Homothétie d'entités topologiques* qui est accessible depuis le panneau *Opérations* en sélectionnant les boutons suivants :

.. taboperation:: 
      :famille: topologie
      :sousfamille: sommets
      :operation: homothétie

On trouve le centre de l'homothétie soit avec la connaissance de la géométrie, en prenant le centre du trou, soit via la console Python en faisant la moyenne de 2 sommets diamétralements opposés.

La commande Python:

.. code-block:: python

  ctx.getTopoManager().scale (["Som0086", "Som0090", "Som0089", "Som0085", "Som0092", "Som0088", "Som0087", "Som0091"], 1.1, Mgx3D.Point(5, 0, 4.25), False)


Découpage en o-grid du bloc du trou
***********************************

Il est recommandé de masquer la topologie de la Cavite pour la suite. Seul le groupe *TMP_TROU* est visible.

Il s'agit maintenant de faire apparaitre un bloc pour le bord de la cavité, pour compléter l\':ref:`o-grid<o-grid>`. Nous utilisons pour cela le bloc du trou que nous redécoupons mais en sélectionnant les faces supérieurs et inférieurs pour que l\':ref:`o-grid<o-grid>` soit autour du bord du trou.

Pour cela ouvrir le panneau *Découpage de bloc avec o-grid* qui est accessible depuis le panneau *Opérations* en sélectionnant les boutons suivants :

.. taboperation:: 
      :famille: topologie
      :sousfamille: blocs
      :operation: découpageblocogrid

Vous allez ensuite sélectionner les entités pour remplir les champs comme suite, puis *Appliquer* :

.. taboperationparams::
      :valeurs: Blocs, Bl0030
                Faces, Fa0131 Fa0130
                Ratio, 0.9

La commande Python :

.. code-block:: python

  ctx.getTopoManager().splitBlocksWithOgrid (["Bl0030"], ["Fa0131", "Fa0130"], .9, 10)

Modification des discrétisations des arêtes de ce bloc
******************************************************

Avant de coller les blocs entre eux, il faut avoir les mêmes discrétisations de part et d'autre. Nous modifions la discrétisation dans l'épaisseur du bloc, en sélectionnant une des arêtes.

Ouvrir le panneau *Paramétrage de la discrétisation des arêtes* qui est accessible depuis le panneau *Opérations* en sélectionnant les boutons suivants :

.. taboperation:: 
      :famille: topologie
      :sousfamille: arêtes
      :operation: discrétisation

Vous allez ensuite sélectionner les entités pour remplir les champs comme suite, puis *Appliquer* :

.. taboperationparams::
      :valeurs: Méthode, Discrétisation d'arêtes parallèles
                Nombre de bras, 4
                Algorithme, Uniforme
                Arêtes, Ar0183

Les commandes Python :

.. code-block:: python

  emp = Mgx3D.EdgeMeshingPropertyUniform(4)
  ctx.getTopoManager().setParallelMeshingProperty (emp,"Ar0183")

Collage des faces du trou avec le reste
***************************************

Rendre visible les groupes *Cavite* et *TMP_TROU*, et uniquement comme type d'entité les *Faces*. Pour le dernier collage, il est nécessaire de rendre visible également le groupe *Vide*.

Il s'agit de coller 2 à deux les faces entre les 2 groupes. En sélectionnant successivement les couples de faces. Sélectionner en premier celles à conserver, celles de la cavité.

Il vous faut ouvrir le panneau *Fusion de faces topologiques entre blocs pas forcément reliés* qui est accessible depuis le panneau *Opérations* en sélectionnant les boutons suivants :

.. taboperation:: 
      :famille: topologie
      :sousfamille: faces
      :operation: fusion

Les commandes Python :

.. code-block:: python

  ctx.getTopoManager().fuse2Faces ("Fa0136","Fa0132")
  ctx.getTopoManager().fuse2Faces ("Fa0134","Fa0160")
  ctx.getTopoManager().fuse2Faces ("Fa0137","Fa0158")
  ctx.getTopoManager().fuse2Faces ("Fa0141","Fa0128")
  ctx.getTopoManager().fuse2Faces ("Fa0139","Fa0152")
  ctx.getTopoManager().fuse2Faces ("Fa0140","Fa0150")
  ctx.getTopoManager().fuse2Faces ("Fa0149","Fa0133")
  ctx.getTopoManager().fuse2Faces ("Fa0147","Fa0161")
  ctx.getTopoManager().fuse2Faces ("Fa0148","Fa0159")
  ctx.getTopoManager().fuse2Faces ("Fa0143","Fa0156")
  ctx.getTopoManager().fuse2Faces ("Fa0145","Fa0129")
  ctx.getTopoManager().fuse2Faces ("Fa0144","Fa0154")
  ctx.getTopoManager().fuse2Faces ("Fa0118","Fa0164")

Rectification des groupes
*************************

Il faut associer le bloc du centre au volume du trou et ceux autour au volume troué de la cavité. Et nous retirons les blocs du groupe *TMP_TROU*, ce groupe était là pour nous permettre de travailler sur la topologie extraite.

Ouvrir le panneau *Associations blocs topologiques -> volume géométrique* qui est accessible depuis le panneau *Opérations* en sélectionnant les boutons suivants:

.. taboperation:: 
      :famille: topologie
      :sousfamille: blocs
      :operation: blocsassociations

Puis utiliser le panneau *Ajout/suppression/affectation d'entités topologiques à un groupe* qui est accessible depuis le panneau *Opérations* en sélectionnant les boutons suivants :

.. taboperation:: 
      :famille: topologie
      :sousfamille: blocs
      :operation: topotogroupe

Les commandes Python :

.. code-block:: python

  ctx.getTopoManager().setGeomAssociation (["Bl0035"], "Vol0005", False)
  ctx.getTopoManager().setGeomAssociation (["Bl0033", "Bl0031", "Bl0034", "Bl0032"], "Vol0003", False)
  ctx.getTopoManager().removeFromGroup (["Bl0035", "Bl0032", "Bl0033", "Bl0034", "Bl0031"], 3, "TMP_TROU")

Associations des courbes et faces au bord du trou
*************************************************

Nous n'affichons plus que le groupe *TROU* et les entités Arêtes et Faces. La couleurs des entités affichées nous permet de voir l'état de leur association. 
Nous allons utiliser l'association automatiques pour les arêtes et faces au bord du trou (entre trou et cavité). 
Et nous allons faire les associations à la main pour les faces supérieures et inférieures.

Ouvrir le panneau *Associations blocs topologiques -> volume géométrique* qui est accessible depuis le panneau *Opérations* en sélectionnant les boutons suivants :

.. taboperation:: 
      :famille: topologie
      :sousfamille: arêtes
      :operation: associations

Lorsque les champs du panneau seront remplis comme suite, exécuter la commande avec le bouton *Appliquer* :

.. taboperationparams::
      :valeurs: Méthode, Arêtes -> Courbes
                Arêtes, Ar0227 Ar0223 Ar0225 Ar0229

Il est possible depuis ce panneau de faire également la projection automatiques des faces en sélectionnant la méthode *Faces -> Surfaces*. Sélectionner les 4 faces au bord du trou et *Appliquer*.

Et pour terminer, sélectionner la méthode *E. topologiques -> E. géométrique*, ainsi que *Dim2* pour les 2 types d'entités. 
Sélectionner ensuite les couples faces et surfaces supérieurs, exécuter la commande avec le bouton *Appliquer*. Recommencer avec le couple inférieur.

Les commandes Python :

.. code-block:: python

  ctx.getTopoManager().projectEdgesOnCurves (["Ar0227", "Ar0223", "Ar0225", "Ar0229"])
  ctx.getTopoManager().projectFacesOnSurfaces (["Fa0166", "Fa0163", "Fa0162", "Fa0167"])
  ctx.getTopoManager().setGeomAssociation (["Fa0165"], "Surf0023", True)
  ctx.getTopoManager().setGeomAssociation (["Fa0118"], "Surf0022", True)

Modification de la forme des arêtes à l'intérieur de la cavité
**************************************************************

Les arêtes internes à l'ogrid au bord du trou n'ayant pas d'association seront maillées avec un segment et risque de sortir de la cavité. 
Nous allons utiliser l'interpolation par rapport à une arête au bord du trou pour corriger cela. 
Il est recommandé de n'afficher maintenant plus que les arêtes de la cavité et d'activer la représentation de la topologie projetée depuis le menu des paramètres de représentation. 
L'idée étant de passer d'une topologie rectiligne à une courbe pour l\':ref:`o-grid<o-grid>`. 

.. rst-class:: image-with-caption

      ===================     ===================
      |CaviteOgridRect|       |CaviteOgridCrb|
      Sans interpolation      Avec interpolation
      ===================     ===================

Ouvrir le panneau *Paramétrage de la discrétisation des arêtes* qui est accessible depuis le panneau *Opérations* en sélectionnant les boutons suivants :

.. taboperation:: 
      :famille: topologie
      :sousfamille: arêtes
      :operation: discrétisation

Utiliser le bouton *Actualiser le panneau* pour initialiser correctement le nombre de bras, après avoir sélectionner l'arête à modifier.

Lorsque les champs du panneau seront remplis comme suit, exécuter la commande avec le bouton *Appliquer* :

.. taboperationparams::
      :valeurs: Méthode, Discrétisation liste d'arêtes 
                Algorithme, Interpolation / face ou 1 ensemble d'arêtes
                Arêtes de référence, Ar0165
                Arêtes, Ar0207 Ar0206
                
Et recommencer pour les couples d'arêtes tout autour du trou et une des arêtes au bord du trou.

Les commandes Python :

.. code-block:: python

  emp = Mgx3D.EdgeMeshingPropertyInterpolate(10, ["Ar0165"])
  ctx.getTopoManager().setMeshingProperty (emp,["Ar0207", "Ar0206"])
  emp = Mgx3D.EdgeMeshingPropertyInterpolate(10, ["Ar0166"])
  ctx.getTopoManager().setMeshingProperty (emp,["Ar0212", "Ar0213"])
  emp = Mgx3D.EdgeMeshingPropertyInterpolate(20, ["Ar0161"])
  ctx.getTopoManager().setMeshingProperty (emp,["Ar0210", "Ar0211"])
  emp = Mgx3D.EdgeMeshingPropertyInterpolate(20, ["Ar0157"])
  ctx.getTopoManager().setMeshingProperty (emp,["Ar0208", "Ar0209"])

Maillage
********
Vous pouvez utiliser le bouton *Tout mailler* de la barre de menu.

La commande Python :

.. code-block:: python

  ctx.getMeshManager().newAllBlocksMesh()

.. figure:: ../images/Cavite2.jpeg

  Vue d'un feuillet et des courbes

Le script final
***************

Le fichier avec toutes les commandes est disponible :download:`ici <../resources/cea_cavite_tel.py>`

.. |caviteVolumes| image:: ../images/cea_Cavite_volumes.jpeg
      :width: 350px

.. |caviteCourbes2D| image:: ../images/cea_Cavite_courbes2D.jpeg
      :width: 350px

.. |caviteAretes3D| image:: ../images/cea_Cavite_aretes3D.jpeg   
      :width: 350px

.. |caviteTrouee| image:: ../images/cea_Cavite_trouee.jpeg   
      :width: 350px

.. |cavitePosBlocsTrou| image:: ../images/cea_Cavite_pos_blocs_trou.jpeg   
      :width: 350px

.. |CaviteOgridRect| image:: ../images/cea_Cavite_ogrid_rect.jpeg
      :height: 350px

.. |CaviteOgridCrb| image:: ../images/cea_Cavite_ogrid_crb.jpeg
      :height: 350px
