.. _cea_annexe-job34:

Pointages laser et diagnostics pour Job34
******************************************

Vous trouverez ci-dessous le descriptif des opérations à effectuer pour
mettre au point le jeu de donner propre aux lasers pour les codes T et D
pour une simulation d’un cas Job34.

Nous allons utiliser le maillage obtenu dans la session *Magix3D*.
Ci-dessous une vue de l’or et de la mousse :

|image234|

Ce maillage a été réalisé avec un cylindre principal sur l’axe des X
pour la cavité et une ouverture avec de la mousse sur l’axe des Y.

Pour compléter les informations associées à ce maillage il faut aller
sélectionner dans le menu « Session » l’unité : *cm*, et le repère :
*maillage*.

Ensuite il est nécessaire de sélectionner soit la surface interne de la
géométrie de l’OR soit la surface de maillage associée, soit le volume
de maillage OR.

Ci-dessous les menus utilisés pour sélectionner le volume de mailles de
l’OR :

|image235|

Une fois cette sélection faite, aller dans le menu « Chambre
Expérimentale » et sélectionner « Utiliser ce contexte » (désormais ceci
est fait automatiquement).

Depuis le menu « Chambre expérimentale » importer les pointages laser et
sélectionner pour notre cas le fichier **lmj_2016.xml**. En faire autant
pour les diagnostics en important le fichier **lmj_diagnostics.xml**. Le
panneau « Pointages laser » ressemble alors à ce qui est ci-dessous :

|image236|

Nous activons la représentation des pointages soit en sélectionnant les
2 anneaux et dans le menu contextuel en utilisant l’action « Afficher
les pointages lasers » ou en cliquant directement la case à cocher de
chacun des 2 anneaux. En faire autant avec le diagnostic **SID_S16**.

Si les pointages lasers n’apparaissent pas c’est surement que vous avez
omis la sélection des surfaces de projection et dans ce cas la boite
englobante est de taille nulle. Vous pouvez recommencer cette étape de
sélection à tout moment ou modifier les options de la boite englobante.

A cette étape il apparait que le diagnostic ne pointe pas suivant l’axe
de l’ouverture de la mousse alors que les pointages sont à peu près bien
placer puisqu’ils entrent de part et d’autre de l’OR.

En plaçant le curseur de la souris sur le diagnostic qui nous intéresse,
il apparait un menu d’informations sur ce diagnostic :

|image237|

Vous pouvez y voir que l’angle *phi* du diagnostic dans la chambre est
de 58.5.

L’étape la plus délicate et la plus important est la sélection de la
transformation entre le repère chambre et le repère maillage.

Dans notre cas nous avons pris comme transformation **phi=58.5** pour
aligner le diagnostic avec l’axe d’ouverture côté mousse et nous avons
ajouté une translation pour que les faisceaux laser pointent sur la
paroi de l’or et non au centre de la cible. Vu le rayon de la cible nous
avons sélectionner **Dy=-0.13**.

En jouant sur la couleur du diagnostic et sur la transparence du
maillage nous observons que les faisceaux et le diagnostic pointent là
où c’est prévu dans l’expérimentation :

|image238|

Il ne nous reste plus qu’à utiliser le menu *Enregistrer sous les
pointages laser* pour sauvegarder les données pour le code T.

Pour le code D, il nous faut utiliser le menu *Informations code
diagnostic* pour accéder aux informations que nous pouvons
copier-coller.

.. note::
    Dans notre cas, il n’y a pas d’inclinaison (angle
    Théta) entre les 2 repères et les faisceaux pointent au centre de la
    chambre.

.. |image234| image:: ../images/cea_image156.jpeg
      :width: 350px

.. |image235| image:: ../images/cea_image157.jpeg
      :width: 350px

.. |image236| image:: ../images/cea_image158.jpeg
      :width: 350px

.. |image237| image:: ../images/cea_image159.jpeg
      :width: 350px

.. |image238| image:: ../images/cea_image161.jpeg
      :width: 350px
