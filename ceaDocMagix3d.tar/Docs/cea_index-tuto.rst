:doc:`pages/cea_tuto-CaviteAvecUnTrou`
   |Cavite1| Tutoriel qui donne une méthode pour la réalisation d'un trou dans une cavité laser avec un maillage en ogrid dans l'épaisseur de la cavité et autour du trou

:doc:`pages/cea_tuto-MaillageA`
   Tutoriel qui donne une méthode pour la réalisation du maillage d'une amorce

.. |Cavite1| image:: ./images/cea_Cavite1.jpeg
   :width: 100px
   :align: bottom